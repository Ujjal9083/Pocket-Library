package com.pocketlibrary.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.*;
import android.graphics.Color;
public class MainActivity extends Activity {
 private WebView web; private SharedPreferences prefs;
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(38,59,49));getWindow().setNavigationBarColor(Color.rgb(38,59,49));prefs=getSharedPreferences("pocket_library",MODE_PRIVATE);web=new WebView(this);web.setBackgroundColor(Color.rgb(251,248,239));web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(true);web.getSettings().setAllowContentAccess(false);web.setWebViewClient(new WebViewClient());web.addJavascriptInterface(new Bridge(),"Android");setContentView(web);web.loadUrl("file:///android_asset/index.html");}
 public class Bridge {
  @JavascriptInterface public String loadLibrary(){return prefs.getString("library","{\"books\":[]}");}
  @JavascriptInterface public void exitApp(){runOnUiThread(()->finish());}
  @JavascriptInterface public void saveLibrary(String json){prefs.edit().putString("library",json).apply();}
  @JavascriptInterface public void exportText(String title,String text){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,title);i.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(i,"Export your library"));});}
 }
 @Override public void onBackPressed(){web.evaluateJavascript("if(document.getElementById('editorView').style.display==='block'){document.getElementById('back').click()}else{window.__onAndroidBack&&window.__onAndroidBack()}",null);}
}
