# Pocket Library

Offline-first Android book and notes app with a library-style interface.

## Included
- Create, rename and delete books
- Add, rename, switch and delete pages
- Bold, italic, underline, strikethrough
- Highlight and text colours
- Font family and size controls
- Left/center alignment, bullet and numbered lists
- Undo, redo, clear formatting
- Automatic local saving
- Search across book titles and page text
- Dark/light theme
- Export the library as plain text through Android's share sheet

## Build
Open this folder in Android Studio. Install Android SDK Platform 35, sync Gradle, then choose Build > Build Bundle(s) / APK(s) > Build APK(s). The debug APK will be at app/build/outputs/apk/debug/app-debug.apk.

## Size and privacy
No network permission or third-party runtime libraries are used. The app stores its content locally. The APK is designed to stay comfortably below 50 MB, but its actual size must be measured after building.

## Build status
This is the Android Studio source project. An APK has not been compiled here because this environment does not have the Android SDK or Gradle installed.
